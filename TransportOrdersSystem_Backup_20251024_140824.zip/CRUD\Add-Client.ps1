﻿# Scripts/CRUD/Add-Client.ps1

param(
    [string]$ProjectPath = "C:\Projects\TransportOrdersSystem",
    [string]$Name,
    [string]$Email,
    [string]$Phone
)

# Проверка обязательных параметров
if (-not $Name -or -not $Email -or -not $Phone) {
    Write-Error "Все параметры (Name, Email, Phone) обязательны."
    return
}

# Пути к файлам данных
$DataPath = Join-Path $ProjectPath "Data"
$ClientsFile = Join-Path $DataPath "clients.json"

# Проверка существования файла клиентов
if (-not (Test-Path $ClientsFile)) {
    Write-Error "Файл $ClientsFile не найден. Инициализируйте проект."
    return
}

# Чтение данных из файла
$Clients = Get-Content $ClientsFile -Raw | ConvertFrom-Json
if ($Clients -isnot [array]) {
    # Если в файле один объект, ConvertFrom-Json возвращает PSCustomObject, а не массив
    if ($Clients -ne $null) {
        $Clients = @($Clients)
    } else {
        $Clients = @()
    }
}

# Генерация нового ID
$NewId = if ($Clients.Count -eq 0) { 1 } else { ($Clients | Measure-Object -Property id -Maximum).Maximum + 1 }

# Создание нового клиента
$NewClient = @{
    id = $NewId
    name = $Name
    contact_info = @{
        email = $Email
        phone = $Phone
    }
}

# Добавление клиента в массив
$Clients += $NewClient

# Сохранение обратно в файл
$Clients | ConvertTo-Json -Depth 10 | Out-File -FilePath $ClientsFile -Encoding UTF8

Write-Host "Новый клиент добавлен: ID $($NewClient.id), Имя: $($NewClient.name)" -ForegroundColor Green